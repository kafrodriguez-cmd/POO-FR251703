package ejemplo2;

public class NumeroComplejo implements INumero {

    // ==========================
    // ATRIBUTOS
    // ==========================

    private double real;
    private double imaginario;

    // ==========================
    // CONSTRUCTORES
    // ==========================

    public NumeroComplejo() {
        this.real = 0;
        this.imaginario = 0;
    }

    public NumeroComplejo(double real) {
        this.real = real;
        this.imaginario = 0;
    }

    public NumeroComplejo(double real, double imaginario) {
        this.real = real;
        this.imaginario = imaginario;
    }

    // ==========================
    // GETTERS Y SETTERS
    // ==========================

    public double getReal() {
        return real;
    }

    public void setReal(double real) {
        this.real = real;
    }

    public double getImaginario() {
        return imaginario;
    }

    public void setImaginario(double imaginario) {
        this.imaginario = imaginario;
    }

    // ==========================
    // METODO CONJUGADA
    // ==========================

    public INumero Conjugada() {

        return new NumeroComplejo(
                this.real,
                -this.imaginario
        );
    }

    // ==========================
    // IMPLEMENTACION INUMERO
    // ==========================

    @Override
    public INumero Sumarle(INumero valor) {

        if (valor instanceof NumeroComplejo) {

            NumeroComplejo c =
                    (NumeroComplejo) valor;

            return new NumeroComplejo(
                    this.real + c.real,
                    this.imaginario + c.imaginario
            );
        }

        return null;
    }

    @Override
    public INumero Dividir(INumero valor) {

        if (valor instanceof NumeroComplejo) {

            NumeroComplejo c =
                    (NumeroComplejo) valor;

            double denominador =
                    (c.real * c.real)
                            +
                            (c.imaginario * c.imaginario);

            if (denominador == 0) {
                throw new ArithmeticException(
                        "No se puede dividir entre cero");
            }

            double nuevaParteReal =
                    ((this.real * c.real)
                            +
                            (this.imaginario * c.imaginario))
                            / denominador;

            double nuevaParteImaginaria =
                    ((this.imaginario * c.real)
                            -
                            (this.real * c.imaginario))
                            / denominador;

            return new NumeroComplejo(
                    nuevaParteReal,
                    nuevaParteImaginaria
            );
        }

        return null;
    }

    @Override
    public INumero ElevarA(int n) {

        if (n == 0) {
            return new NumeroComplejo(1, 0);
        }

        NumeroComplejo resultado =
                new NumeroComplejo(real, imaginario);

        for (int i = 1; i < Math.abs(n); i++) {

            resultado =
                    multiplicar(resultado,
                            this);
        }

        if (n < 0) {

            NumeroComplejo uno =
                    new NumeroComplejo(1, 0);

            return uno.Dividir(resultado);
        }

        return resultado;
    }

    // ==========================
    // METODO AUXILIAR
    // ==========================

    private NumeroComplejo multiplicar(
            NumeroComplejo a,
            NumeroComplejo b) {

        double r =
                (a.real * b.real)
                        -
                        (a.imaginario * b.imaginario);

        double i =
                (a.real * b.imaginario)
                        +
                        (a.imaginario * b.real);

        return new NumeroComplejo(r, i);
    }

    // ==========================
    // TOSTRING
    // ==========================

    @Override
    public String toString() {

        if (real == 0 && imaginario == 0) {
            return "0.00";
        }

        if (real == 0) {
            return String.format("%.2fi",
                    imaginario);
        }

        if (imaginario == 0) {
            return String.format("%.2f",
                    real);
        }

        if (imaginario > 0) {

            return String.format(
                    "%.2f + %.2fi",
                    real,
                    imaginario);
        }

        return String.format(
                "%.2f - %.2fi",
                real,
                Math.abs(imaginario));
    }
}