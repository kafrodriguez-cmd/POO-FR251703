package ejemplo2;

public class Aplicacion2 {
    public static void mostrarYSumarFracciones(
            NumFraccionario... fracciones) {

        if (fracciones == null ||
                fracciones.length == 0) {

            System.out.println(
                    "Datos recibidos son incompletos, fin de ejecución del metodo");

            return;
        }

        System.out.println("\nLISTA DE FRACCIONES");

        NumFraccionario suma =
                new NumFraccionario(0);

        for (NumFraccionario f : fracciones) {

            System.out.println(f);

            suma = (NumFraccionario)
                    suma.Sumarle(f);
        }

        System.out.println(
                "\nSUMA TOTAL = " + suma);
    }

    public static void main(String[] args) {

        // ==========================
        // INSTANCIAS DE PRUEBA
        // ==========================

        NumFraccionario f0;
        NumFraccionario f1;
        NumFraccionario f2;
        NumFraccionario f3;
        NumFraccionario f4;

        NumFraccionario r1;
        INumero r2;
        INumero r3;

        int mcd;
        int mcm;

        System.out.println("================================");
        System.out.println("OPERACIONES CON FRACCIONES");
        System.out.println("================================");

        // ==========================
        // INICIALIZACION
        // ==========================

        f0 = new NumFraccionario();
        f1 = new NumFraccionario(3, 5);
        f2 = new NumFraccionario(7, 8);
        f3 = new NumFraccionario(630, 1050);
        f4 = new NumFraccionario(16);

        System.out.printf(
                "Las fracciones para las pruebas seran %s, %s, %s, %s y %s\n\n",
                f0, f1, f2, f3, f4);

        // ==========================
        // MCD
        // ==========================

        mcd = f0.calcularMCD(630, 1050);

        System.out.printf(
                "MCD(630,1050) = %d\n",
                mcd);

        // ==========================
        // MCM
        // ==========================

        mcm = f0.calcularMCM(
                f1.getDeno(),
                f2.getDeno());

        System.out.printf(
                "MCM(%d,%d) = %d\n\n",
                f1.getDeno(),
                f2.getDeno(),
                mcm);

        // ==========================
        // SIMPLIFICAR
        // ==========================

        System.out.printf(
                "La fraccion equivalente y simplificada de %s ",
                f3);

        r1 = f3.Simplificar();

        System.out.printf(
                "es %s\n",
                r1);

        System.out.printf(
                "La fraccion equivalente y simplificada de 300/270 es %s\n",
                f0.Simplificar(300, 270));

        // ==========================
        // DECIMAL
        // ==========================

        f0 = new NumFraccionario(-23, 125);

        System.out.printf(
                "El valor decimal de la fraccion %s es %.4f\n\n",
                f0,
                f0.aDecimal());

        // ==========================
        // SUMA DE FRACCIONES
        // ==========================

        r2 = f1.Sumarle(f2);

        System.out.printf(
                "La suma de %s con %s es %s\n",
                f1,
                f2,
                r2);

        // ==========================
        // SUMA FRACCION + ENTERO
        // ==========================

        f0 = (NumFraccionario) f1.Sumarle(f4);

        System.out.printf(
                "La suma de %s y %s es %s\n",
                f1,
                f4,
                f0);

        // ==========================
        // COMPARACION
        // ==========================

        if (f1.EsMayorQue(f4)) {

            System.out.printf(
                    "La fraccion %s es mayor que %s\n",
                    f1,
                    f4);

        } else {

            System.out.printf(
                    "La fraccion %s es mayor que %s\n",
                    f4,
                    f1);
        }

        // ==========================
        // DIVISION
        // ==========================

        System.out.println("\nPRUEBAS DE DIVISION");

        NumFraccionario a =
                new NumFraccionario(2, 3);

        System.out.println(
                a + " / 4/9 = "
                        + a.Dividir(
                        new NumFraccionario(4, 9)));

        System.out.println(
                a + " / -3/7 = "
                        + a.Dividir(
                        new NumFraccionario(-3, 7)));

        System.out.println(
                a + " / -28/16 = "
                        + a.Dividir(
                        new NumFraccionario(-28, 16)));

        System.out.println(
                a + " / 16 = "
                        + a.Dividir(
                        new NumFraccionario(16)));

        // ==========================
        // POTENCIAS
        // ==========================

        System.out.println("\nPRUEBAS DE POTENCIAS");

        r3 = new NumFraccionario(1, 3)
                .ElevarA(2);

        System.out.println(
                "(1/3)^2 = " + r3);

        r3 = new NumFraccionario(1, 2)
                .ElevarA(-3);

        System.out.println(
                "(1/2)^-3 = " + r3);

        r3 = new NumFraccionario(3, 2)
                .ElevarA(3);

        System.out.println(
                "(3/2)^3 = " + r3);

        System.out.println("\nFIN DE PRUEBAS");
    }
}