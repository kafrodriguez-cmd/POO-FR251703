package ejemplo2;

public class NumFraccionario implements INumero, IComparable {

    // ==========================
    // ATRIBUTOS
    // ==========================

    private int num;
    private int deno;

    // ==========================
    // CONSTRUCTORES
    // ==========================

    public NumFraccionario() {
        this.num = 0;
        this.deno = 1;
    }

    public NumFraccionario(int num) {
        this.num = num;
        this.deno = 1;
    }

    public NumFraccionario(int num, int deno) {
        this.num = num;
        setDeno(deno);
    }

    // ==========================
    // GETTERS Y SETTERS
    // ==========================

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public int getDeno() {
        return deno;
    }

    public void setDeno(int deno) {

        if (deno == 0) {
            throw new IllegalArgumentException(
                    "El denominador no puede ser cero");
        }

        // Mantener signo en numerador
        if (deno < 0) {
            this.num *= -1;
            deno *= -1;
        }

        this.deno = deno;
    }

    // ==========================
    // METODOS DE APOYO
    // ==========================

    public int calcularMCD(int a, int b) {

        a = Math.abs(a);
        b = Math.abs(b);

        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }

        return a;
    }

    public int calcularMCD(
            NumFraccionario a,
            NumFraccionario b) {

        return calcularMCD(
                a.getDeno(),
                b.getDeno());
    }

    public int calcularMCM(int a, int b) {

        return (a * b) /
                calcularMCD(a, b);
    }

    private boolean EsNegativa() {

        return num < 0;
    }

    public double aDecimal() {

        return (double) num /
                (double) deno;
    }

    // ==========================
    // SIMPLIFICAR
    // ==========================

    public NumFraccionario Simplificar() {

        int mcd =
                calcularMCD(
                        Math.abs(num),
                        Math.abs(deno));

        return new NumFraccionario(
                num / mcd,
                deno / mcd);
    }

    public NumFraccionario Simplificar(
            int n,
            int d) {

        int mcd =
                calcularMCD(
                        Math.abs(n),
                        Math.abs(d));

        return new NumFraccionario(
                n / mcd,
                d / mcd);
    }

    // ==========================
    // INTERFACE INUMERO
    // ==========================

    @Override
    public INumero Sumarle(INumero valor) {

        if (valor instanceof NumFraccionario) {

            NumFraccionario f =
                    (NumFraccionario) valor;

            int nuevoDeno =
                    calcularMCM(
                            this.deno,
                            f.deno);

            int nuevoNum =
                    (this.num *
                            (nuevoDeno / this.deno))
                            +
                            (f.num *
                                    (nuevoDeno / f.deno));

            return new NumFraccionario(
                    nuevoNum,
                    nuevoDeno
            ).Simplificar();
        }

        return null;
    }

    @Override
    public INumero Dividir(INumero valor) {

        if (valor instanceof NumFraccionario) {

            NumFraccionario f =
                    (NumFraccionario) valor;

            int nuevoNum =
                    this.num * f.deno;

            int nuevoDeno =
                    this.deno * f.num;

            return new NumFraccionario(
                    nuevoNum,
                    nuevoDeno
            ).Simplificar();
        }

        return null;
    }

    @Override
    public INumero ElevarA(int n) {

        if (n == 0) {
            return new NumFraccionario(1, 1);
        }

        int nuevoNum;
        int nuevoDeno;

        if (n > 0) {

            nuevoNum =
                    (int) Math.pow(num, n);

            nuevoDeno =
                    (int) Math.pow(deno, n);

        } else {

            n = Math.abs(n);

            nuevoNum =
                    (int) Math.pow(deno, n);

            nuevoDeno =
                    (int) Math.pow(num, n);
        }

        return new NumFraccionario(
                nuevoNum,
                nuevoDeno
        ).Simplificar();
    }

    // ==========================
    // INTERFACE ICOMPARABLE
    // ==========================

    @Override
    public boolean EsMayorQue(Object valor) {

        if (valor instanceof NumFraccionario) {

            NumFraccionario p1 =
                    new NumFraccionario(
                            getNum(),
                            getDeno());

            NumFraccionario p2 =
                    (NumFraccionario) valor;

            if (!p1.EsNegativa()
                    && !p2.EsNegativa()) {

                return p1.aDecimal()
                        > p2.aDecimal();
            }

            if (p1.EsNegativa()
                    && p2.EsNegativa()) {

                return p2.aDecimal()
                        > p1.aDecimal();
            }

            return !p1.EsNegativa();
        }

        return false;
    }

    // ==========================
    // TOSTRING
    // ==========================

    @Override
    public String toString() {

        int absNum = Math.abs(num);

        // Entero
        if (deno == 1) {
            return String.valueOf(num);
        }

        // Fracción propia
        if (absNum < deno) {
            return num + "/" + deno;
        }

        // Fracción impropia
        int entero = num / deno;

        int residuo = absNum % deno;

        if (residuo == 0) {
            return String.valueOf(entero);
        }

        int mcd = calcularMCD(residuo, deno);

        residuo /= mcd;
        int nuevoDeno = deno / mcd;

        return entero + "(" +
                residuo + "/" +
                nuevoDeno + ")";
    }
}