package ejemplo2;

public interface INumero {

    INumero Sumarle(INumero valor);

    INumero Dividir(INumero valor);

    INumero ElevarA(int n);

}