package Ejercicio4;

import javax.swing.JOptionPane;

public class SumaEnteros {

    public static void main(String[] args) {

        String primerNumero;
        String segundoNumero;

        int numero1;
        int numero2;
        int suma;

        primerNumero = JOptionPane.showInputDialog("Digite el primer número");
        segundoNumero = JOptionPane.showInputDialog("Digite el segundo número");

        numero1 = Integer.parseInt(primerNumero);
        numero2 = Integer.parseInt(segundoNumero);

        if (numero1 < 0 || numero2 < 0) {
            JOptionPane.showMessageDialog(
                    null,
                    "No se permiten números negativos",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );

            System.exit(0);
        }

        suma = numero1 + numero2;

        JOptionPane.showMessageDialog(
                null,
                "La suma es: " + suma,
                "Resultado",
                JOptionPane.PLAIN_MESSAGE
        );

        System.exit(0);
    }
}