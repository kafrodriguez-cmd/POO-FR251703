package EjercicioTanques;

import java.util.Scanner;

public class TanquesCombustible {

    public static final double DENSIDAD_GASOLINA = 0.750;

    public static double solicitarRadio() {

        Scanner lector = new Scanner(System.in);

        System.out.print("Ingrese el radio del tanque (m): ");
        return lector.nextDouble();
    }

    public static double solicitarAltura() {

        Scanner lector = new Scanner(System.in);

        System.out.print("Ingrese la altura del tanque (m): ");
        return lector.nextDouble();
    }

    public static double calcularVolumenLitros(double radio,
                                               double altura) {

        double volumenMetrosCubicos;

        volumenMetrosCubicos =
                Math.PI * Math.pow(radio, 2) * altura;

        return volumenMetrosCubicos * 1000;
    }

    public static double calcularGasolinaKg(double litros) {

        return litros * DENSIDAD_GASOLINA;
    }

    public static void imprimirResultados(double litrosDiesel,
                                          double gasolinaKg) {

        System.out.println("\n===== RESULTADOS =====");

        System.out.println("Capacidad Diesel: "
                + litrosDiesel + " litros");

        System.out.println("Capacidad Gasolina: "
                + gasolinaKg + " kg");
    }

    public static void main(String[] args) {

        double radio;
        double altura;

        double litrosDiesel;
        double gasolinaKg;

        radio = solicitarRadio();
        altura = solicitarAltura();

        litrosDiesel = calcularVolumenLitros(radio, altura);

        gasolinaKg = calcularGasolinaKg(litrosDiesel);

        imprimirResultados(litrosDiesel, gasolinaKg);
    }
}