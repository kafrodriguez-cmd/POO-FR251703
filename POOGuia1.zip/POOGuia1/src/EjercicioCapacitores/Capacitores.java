package EjercicioCapacitores;

import javax.swing.JOptionPane;

public class Capacitores {

    public static double calcularSerie(double c1, double c2, double c3) {

        return 1.0 / ((1.0 / c1) + (1.0 / c2) + (1.0 / c3));
    }

    public static double calcularParalelo(double c1, double c2, double c3) {

        return c1 + c2 + c3;
    }

    public static void main(String[] args) {

        String dato1;
        String dato2;
        String dato3;

        double c1;
        double c2;
        double c3;

        dato1 = JOptionPane.showInputDialog(
                "Ingrese el capacitor 1 (μF)"
        );

        dato2 = JOptionPane.showInputDialog(
                "Ingrese el capacitor 2 (μF)"
        );

        dato3 = JOptionPane.showInputDialog(
                "Ingrese el capacitor 3 (μF)"
        );

        if (dato1 == null || dato2 == null || dato3 == null ||
                dato1.isEmpty() || dato2.isEmpty() || dato3.isEmpty()) {

            JOptionPane.showMessageDialog(
                    null,
                    "No ingresó un valor apropiado"
            );

            System.exit(0);
        }

        c1 = Double.parseDouble(dato1);
        c2 = Double.parseDouble(dato2);
        c3 = Double.parseDouble(dato3);

        if (c1 <= 0 || c2 <= 0 || c3 <= 0) {

            JOptionPane.showMessageDialog(
                    null,
                    "Los valores deben ser mayores que cero"
            );

            System.exit(0);
        }

        System.out.println("=== DATOS INGRESADOS ===");
        System.out.println("C1 = " + c1 + " μF");
        System.out.println("C2 = " + c2 + " μF");
        System.out.println("C3 = " + c3 + " μF");

        System.out.println();

        System.out.println("Capacitor equivalente en serie: "
                + calcularSerie(c1, c2, c3) + " μF");

        System.out.println("Capacitor equivalente en paralelo: "
                + calcularParalelo(c1, c2, c3) + " μF");
    }
}