package Ejercicio1;

public class Ejemplo1 {
    public static void main(String[] args) {
        System.out.print("");
        System.out.print("Soy Ricardo Maldonado y ");
        System.out.print("estoy en el Grupo 01L. \n");
    }
}

