package aplicacion;

import javax.swing.JOptionPane;
import misclases.*;

public class Principal {

    // ==========================
    // PARTE 1
    // ==========================
    public static void parte1() {

        Persona obj1 = new Persona();

        Persona obj2 =
                new Persona(
                        "Manuel",
                        "Valdez",
                        25);

        System.out.println(
                "Datos predeterminados de obj1:");

        obj1.mostrarDatos();

        obj1.ingresoDatos();

        System.out.println(
                "Campos modificados de obj1:");

        obj1.mostrarDatos();

        System.out.println(
                "Datos de obj2:");

        obj2.mostrarDatos();
    }

    // ==========================
    // PARTE 2
    // ==========================
    public static void parte2() {

        Tiempo hora1 = new Tiempo();

        String salida =
                "Hora inicial es:\n"
                        + "Hora universal: "
                        + hora1.aStringUniversal()
                        + "\nHora estándar: "
                        + hora1.aStringEstandar();

        hora1.establecerHora(18, 27, 6);

        salida +=
                "\n\nNueva hora universal: "
                        + hora1.aStringUniversal()
                        + "\nHora estándar: "
                        + hora1.aStringEstandar();

        hora1.setHora(9);
        hora1.setMinuto(52);

        salida +=
                "\n\nHora modificada: "
                        + hora1.aStringEstandar();

        JOptionPane.showMessageDialog(
                null,
                salida,
                "Prueba Clase Tiempo",
                JOptionPane.INFORMATION_MESSAGE);

        hora1.establecerHora(-5, 8, 721);

        salida =
                "Después del ajuste inválido:\n"
                        + "Hora universal: "
                        + hora1.aStringUniversal()
                        + "\nHora estándar: "
                        + hora1.aStringEstandar();

        JOptionPane.showMessageDialog(
                null,
                salida,
                "Clase Tiempo",
                JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {

        // Ejecuta Parte 1
        parte1();

        // Ejecuta Parte 2
        parte2();
    }
}