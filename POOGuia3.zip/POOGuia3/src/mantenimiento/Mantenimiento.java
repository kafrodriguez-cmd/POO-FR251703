package mantenimiento;

import operacionesbanco.*;

import java.util.ArrayList;
import java.util.Scanner;

public class Mantenimiento {

    static Scanner sc = new Scanner(System.in);

    static ArrayList<Cliente> clientes =
            new ArrayList<>();

    static ArrayList<CuentaBancaria> cuentas =
            new ArrayList<>();

    public static void main(String[] args) {

        int opcion;

        do {

            System.out.println("\n========================");
            System.out.println("MENU PRINCIPAL");
            System.out.println("========================");
            System.out.println("1. Registrar Cliente");
            System.out.println("2. Abrir Cuenta");
            System.out.println("3. Salir");

            System.out.print("Opcion: ");

            opcion =
                    Integer.parseInt(sc.nextLine());

            switch (opcion) {

                case 1:
                    registrarCliente();
                    break;

                case 2:
                    abrirCuenta();
                    break;

                case 3:
                    System.out.println("Adios");
                    break;

                default:
                    System.out.println(
                            "Opcion invalida");
            }

        } while (opcion != 3);
    }

    public static void registrarCliente() {

        System.out.println(
                "\nREGISTRAR CLIENTE");

        System.out.print("Nombre: ");
        String nombre = sc.nextLine();

        System.out.print("Apellido: ");
        String apellido = sc.nextLine();

        System.out.print("DUI: ");
        String dui = sc.nextLine();

        Cliente nuevo =
                new Cliente(
                        nombre,
                        apellido,
                        dui);

        clientes.add(nuevo);

        System.out.println(
                "\nClientes registrados ("
                        + clientes.size()
                        + ")\n");

        for (int i = 0; i < clientes.size(); i++) {

            System.out.println(
                    (i + 1) + ". "
                            + clientes.get(i)
                            .DatosCliente());
        }
    }

    public static void abrirCuenta() {

        if (clientes.isEmpty()) {

            System.out.println(
                    "No existen clientes.");
            return;
        }

        System.out.println(
                "\nCLIENTES DISPONIBLES\n");

        for (int i = 0; i < clientes.size(); i++) {

            System.out.println(
                    (i + 1) + ". "
                            + clientes.get(i)
                            .DatosCliente());
        }

        System.out.print(
                "\nSeleccione cliente: ");

        int posicion =
                Integer.parseInt(
                        sc.nextLine());

        if (posicion < 1 ||
                posicion > clientes.size()) {

            System.out.println(
                    "Cliente invalido");
            return;
        }

        Cliente cliente =
                clientes.get(posicion - 1);

        System.out.print(
                "Monto inicial: $");

        double monto =
                Double.parseDouble(
                        sc.nextLine());

        CuentaBancaria cuenta =
                new CuentaBancaria(
                        cliente,
                        monto);

        cuentas.add(cuenta);

        System.out.println(
                "\nCuenta creada exitosamente\n");

        cuenta.vertransacciones();
    }
}