package operacionesbanco;

import java.util.ArrayList;

public class CuentaBancaria {

    private Cliente titularcuenta;
    private double saldoactual;
    private int numtransac;

    private ArrayList<TransaccionCuenta> transacciones;

    private void inicializarCampos() {

        titularcuenta = null;
        saldoactual = 0;
        numtransac = 0;

        transacciones = new ArrayList<>();
    }

    public CuentaBancaria(
            Cliente propietario,
            double saldoinicial) {

        inicializarCampos();

        titularcuenta = propietario;

        TransaccionCuenta transacTemp =
                new TransaccionCuenta(++numtransac, 0);

        transacTemp.Ejecutar(
                'd',
                saldoinicial,
                "apertura de cuenta");

        saldoactual = transacTemp.getNuevosaldo();

        transacciones.add(transacTemp);
    }

    public void realizaroperacion(
            char tipooperac,
            double monto,
            String descripcion) {

        TransaccionCuenta transacTemp =
                new TransaccionCuenta(
                        numtransac + 1,
                        saldoactual);

        transacTemp.Ejecutar(
                tipooperac,
                monto,
                descripcion);

        switch (transacTemp.getEstado()) {

            case 1:
                System.out.println(
                        "ERROR: Saldo insuficiente");
                break;

            case 2:
                System.out.println(
                        "ERROR: Monto negativo");
                break;

            default:

                numtransac++;

                saldoactual =
                        transacTemp.getNuevosaldo();

                transacciones.add(transacTemp);

                System.out.println(
                        "Transaccion ejecutada");
        }
    }

    public void vertransacciones() {

        System.out.println(
                "\nTitular: "
                        + titularcuenta.DatosCliente());

        System.out.println(
                "Saldo actual: $"
                        + saldoactual);

        System.out.println(
                "-------------------------------------------------------------");

        for (TransaccionCuenta t : transacciones) {
            System.out.println(t.getRegistro());
        }
    }

    public double getSaldoactual() {
        return saldoactual;
    }

    public Cliente getTitularcuenta() {
        return titularcuenta;
    }
}