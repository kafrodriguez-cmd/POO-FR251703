package misclases;

import javax.swing.*;

public class Persona {

    // Atributos
    private String nombre;
    private String apellido;
    private int edad;

    // Constructor por defecto
    public Persona() {
        nombre = "Rafael";
        apellido = "Torres";
        edad = 23;
    }

    // Constructor con parámetros
    public Persona(String nom, String apell, int edad) {
        this.nombre = nom;
        this.apellido = apell;
        this.edad = edad;
    }

    // Solicita datos
    public void ingresoDatos() {

        nombre = JOptionPane.showInputDialog("Ingrese el Nombre");

        apellido = JOptionPane.showInputDialog("Ingrese el Apellido");

        edad = Integer.parseInt(
                JOptionPane.showInputDialog("Ingrese su edad"));
    }

    // Muestra datos
    public void mostrarDatos() {

        System.out.println("Su nombre es: " + nombre);
        System.out.println("Su apellido es: " + apellido);
        System.out.println("Su edad es: " + edad);
        System.out.println("****************************");
    }
}