package misclases;

import java.text.DecimalFormat;

public class Tiempo {

    private int hora;
    private int minuto;
    private int segundo;

    // Inicializa campos
    private void inicializarCampos() {

        hora = 0;
        minuto = 0;
        segundo = 0;
    }

    // Constructor
    public Tiempo() {
        inicializarCampos();
    }

    // Modifica hora
    public void establecerHora(int h, int m, int s) {

        setHora(h);
        setMinuto(m);
        setSegundo(s);
    }

    // Formato 24 horas
    public String aStringUniversal() {

        DecimalFormat dosDigitos =
                new DecimalFormat("00");

        return dosDigitos.format(hora)
                + ":"
                + dosDigitos.format(minuto)
                + ":"
                + dosDigitos.format(segundo);
    }

    // Formato AM/PM
    public String aStringEstandar() {

        DecimalFormat dosDigitos =
                new DecimalFormat("00");

        return ((hora == 12 || hora == 0)
                ? 12
                : hora % 12)
                + ":"
                + dosDigitos.format(minuto)
                + ":"
                + dosDigitos.format(segundo)
                + (hora < 12 ? " AM" : " PM");
    }

    // GET y SET

    public int getHora() {
        return hora;
    }

    public void setHora(int hora) {

        if (hora >= 0 && hora < 24) {
            this.hora = hora;
        }
    }

    public int getMinuto() {
        return minuto;
    }

    public void setMinuto(int minuto) {

        if (minuto >= 0 && minuto < 60) {
            this.minuto = minuto;
        }
    }

    public int getSegundo() {
        return segundo;
    }

    public void setSegundo(int segundo) {

        if (segundo >= 0 && segundo < 60) {
            this.segundo = segundo;
        }
    }
}