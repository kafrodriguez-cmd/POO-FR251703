package EjerciciosIF;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class BibliotecaCRUD {

    static HashMap<String, String> libros = new HashMap<>();

    static Scanner sc = new Scanner(System.in);

    // Validación ISBN
    static boolean validarISBN(String isbn) {
        return isbn.matches("\\d{13}");
    }

    // CREATE
    static void agregarLibro() {

        String isbn;

        int intentos = 0;

        do {
            System.out.print("ISBN (13 digitos): ");
            isbn = sc.nextLine();

            if (validarISBN(isbn))
                break;

            intentos++;
            System.out.println("ISBN incorrecto");

        } while (intentos < 3);

        if (!validarISBN(isbn))
            return;

        System.out.print("Titulo: ");
        String titulo = sc.nextLine();

        libros.put(isbn, titulo);

        System.out.println("Libro agregado");
    }

    // READ
    static void consultarLibro() {

        System.out.print("ISBN: ");
        String isbn = sc.nextLine();

        if (libros.containsKey(isbn)) {
            System.out.println("Titulo: " + libros.get(isbn));
        } else {
            System.out.println("Libro no encontrado");
        }
    }

    // UPDATE
    static void actualizarLibro() {

        System.out.print("ISBN a modificar: ");
        String isbn = sc.nextLine();

        if (libros.containsKey(isbn)) {

            System.out.print("Nuevo titulo: ");
            String nuevoTitulo = sc.nextLine();

            libros.put(isbn, nuevoTitulo);

            System.out.println("Libro actualizado");
        }
        else {
            System.out.println("Libro no encontrado");
        }
    }

    // DELETE
    static void eliminarLibro() {

        System.out.print("ISBN a eliminar: ");
        String isbn = sc.nextLine();

        if (libros.containsKey(isbn)) {

            libros.remove(isbn);

            System.out.println("Libro eliminado");
        }
        else {
            System.out.println("Libro no encontrado");
        }
    }

    static void mostrarLibros() {

        if (libros.isEmpty()) {
            System.out.println("No hay libros registrados");
            return;
        }

        System.out.println("\nLISTA DE LIBROS");

        for (Map.Entry<String, String> libro : libros.entrySet()) {

            System.out.println(
                    "ISBN: " + libro.getKey() +
                            " | Titulo: " + libro.getValue());
        }
    }

    public static void main(String[] args) {

        int opcion;

        do {

            System.out.println("\n===== BIBLIOTECA =====");
            System.out.println("1. Agregar");
            System.out.println("2. Consultar");
            System.out.println("3. Actualizar");
            System.out.println("4. Eliminar");
            System.out.println("5. Mostrar");
            System.out.println("6. Salir");

            System.out.print("Opcion: ");
            opcion = Integer.parseInt(sc.nextLine());

            switch (opcion) {

                case 1:
                    agregarLibro();
                    break;

                case 2:
                    consultarLibro();
                    break;

                case 3:
                    actualizarLibro();
                    break;

                case 4:
                    eliminarLibro();
                    break;

                case 5:
                    mostrarLibros();
                    break;

                case 6:
                    System.out.println("Programa finalizado");
                    break;

                default:
                    System.out.println("Opcion incorrecta");
            }

        } while (opcion != 6);
    }
}