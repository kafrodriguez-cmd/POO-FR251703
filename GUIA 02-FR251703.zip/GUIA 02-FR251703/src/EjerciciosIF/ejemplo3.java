package EjerciciosIF;

import javax.swing.*;

public class ejemplo3 {
    static void ejemplo3() {
        int result = JOptionPane.showConfirmDialog(
                null,
                "Replace existing selection?");

        System.out.println(
                "El numero devuelto por showConfirmDialog es: " + result);

        switch (result) {
            case JOptionPane.YES_OPTION:
                System.out.println("Yes");
                break;

            case JOptionPane.NO_OPTION:
                System.out.println("No");
                break;

            case JOptionPane.CANCEL_OPTION:
                System.out.println("Cancel");
                break;

            case JOptionPane.CLOSED_OPTION:
                System.out.println("Closed");
                break;

            default:
                System.out.println("Opción desconocida");
        }

        System.exit(0);
    }
}
