package EjerciciosIF;
import java.util.Random;

public class DescuentoTienda {

    static void aplicarDescuento(String cliente, double compra) {

        String[] colores = {"Cafe", "Roja", "Azul", "Verde"};

        Random random = new Random();

        int indice = random.nextInt(colores.length);

        String color = colores[indice];

        double descuento = 0;

        switch (color) {

            case "Cafe":
                descuento = 0.10;
                break;

            case "Roja":
                descuento = 0.15;
                break;

            case "Azul":
                descuento = 0.25;
                break;

            case "Verde":
                descuento = 0.50;
                break;
        }

        double montoDescuento = compra * descuento;
        double total = compra - montoDescuento;

        System.out.println("Cliente: " + cliente);
        System.out.println("Color obtenido: " + color);
        System.out.println("Compra: $" + compra);
        System.out.println("Descuento: $" + montoDescuento);
        System.out.println("Total a pagar: $" + total);
    }

    public static void main(String[] args) {

        aplicarDescuento("Carlos Perez", 250);

    }
}