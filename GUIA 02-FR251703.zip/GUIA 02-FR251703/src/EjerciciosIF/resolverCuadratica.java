package EjerciciosIF;

public class resolverCuadratica {
    public static void main(String[] args) {

        resolverCuadratica(1, -5, 6);

    }
    static double determinante(double a, double b, double c) {
        return (b * b) - (4 * a * c);
    }
    static void resolverCuadratica(double a, double b, double c) {

        double d = determinante(a, b, c);

        if (d > 0) {
            double x1 = (-b + Math.sqrt(d)) / (2 * a);
            double x2 = (-b - Math.sqrt(d)) / (2 * a);

            System.out.println("Raices reales distintas:");
            System.out.println("x1 = " + x1);
            System.out.println("x2 = " + x2);
        }
        else if (d == 0) {
            double x = (-b) / (2 * a);

            System.out.println("Raiz real doble:");
            System.out.println("x = " + x);
        }
        else {
            double real = -b / (2 * a);
            double imaginaria = Math.sqrt(-d) / (2 * a);

            System.out.println("Raices complejas:");
            System.out.println("x1 = " + real + " + " + imaginaria + "i");
            System.out.println("x2 = " + real + " - " + imaginaria + "i");
        }
    }
}
